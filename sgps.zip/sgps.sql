-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2017 at 12:08 AM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sgps`
--

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `morada` varchar(45) DEFAULT NULL,
  `celular` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `tipocliente` varchar(45) DEFAULT NULL,
  `datareg` date DEFAULT NULL,
  `tipodoc` varchar(45) DEFAULT NULL,
  `Pacote` varchar(60) DEFAULT NULL,
  `Servico` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nome`, `morada`, `celular`, `email`, `tipocliente`, `datareg`, `tipodoc`, `Pacote`, `Servico`) VALUES
(58, 'DDDDD', 'XHJGJ', '7656567', 'JHVJHKG', 'Contrato Mensal', '2017-10-27', 'B.I.', NULL, NULL),
(59, 'TTTTTT', 'JVHGH', '7676', 'KJHKJ', 'Contrato Mensal', '2017-10-27', 'B.I.', NULL, NULL),
(60, 'UUUUU', 'JBSDJBJH', '5874657', 'HDSGDFHS', 'Contrato Mensal', '2017-10-27', 'B.I.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contratos`
--

CREATE TABLE `contratos` (
  `idContratos` int(11) NOT NULL,
  `tipodecontrato` varchar(45) DEFAULT NULL,
  `Cliente_idCliente` int(11) NOT NULL,
  `servicos_idServicos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pacote`
--

CREATE TABLE `pacote` (
  `idPacote` int(11) NOT NULL,
  `NomeDoPacote` varchar(50) NOT NULL,
  `servicos_idServicos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pacote`
--

INSERT INTO `pacote` (`idPacote`, `NomeDoPacote`, `servicos_idServicos`) VALUES
(1, 'Net Basico', 2),
(2, 'Net Mais', 2),
(3, 'Net Bwe Plus', 2),
(4, 'Energia de 50', 3),
(5, 'Energia de 100', 3),
(6, 'Energia de 200', 3),
(7, 'Propina Mensal', 4),
(8, 'Propina Semestral', 4),
(9, 'Propina Anual', 4),
(10, 'Agua de 500 litros', 5),
(11, 'Agua de 1000 litros', 5),
(12, 'Agua de 2000 litros', 5),
(13, 'Base', 1),
(14, 'Plus', 1),
(15, 'Zap Mega', 1),
(16, 'Cinquentinha 50', 6),
(17, 'Credito 100', 7),
(18, 'Credito 10', 8);

-- --------------------------------------------------------

--
-- Table structure for table `pagamento`
--

CREATE TABLE `pagamento` (
  `idPagamento` int(11) NOT NULL,
  `nomeCliente` varchar(255) NOT NULL,
  `Servico` varchar(200) DEFAULT NULL,
  `Pacote` varchar(200) DEFAULT NULL,
  `datapag` date DEFAULT NULL,
  `valorpago` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pagamento`
--

INSERT INTO `pagamento` (`idPagamento`, `nomeCliente`, `Servico`, `Pacote`, `datapag`, `valorpago`) VALUES
(11, 'Jose Maria', '4-Propinas', '9-Propina Anual', '2017-05-09', 53435453),
(12, 'Vitoria Na Guerra', '4-Propinas', '9-Propina Anual', '2017-05-02', 4345345),
(13, 'Angelo', '5-Agua', '11-Agua de 1000 litros', '2017-05-04', 123132),
(14, 'Jeremias', '4-Propinas', '9-Propina Anual', '2017-05-18', 546556),
(15, 'Jeremias Constantino', '1-Tv', '14-Plus', '2017-05-15', 5664),
(16, 'Jeremias Constantino', '4-Propinas', 'Seleciona', '2017-05-17', 65988),
(17, 'Armando ', '3-Energia', '4-Energia de 50', '2017-05-04', 32345),
(18, 'Gerson', '3-Energia', '5-Energia de 100', '2017-05-24', 5245),
(19, 'Jose', '3-Energia', '5-Energia de 100', '2017-05-12', 4544),
(20, 'Vann', '2-Internet', '2-Net Mais', '2017-05-18', 5665),
(21, 'Edson Gomes', '4-Propinas', 'Seleciona', '2017-05-10', 7889),
(22, 'Anglelo', '1-Tv', '13-Base', '2017-05-09', 6544),
(23, 'Armando ', '5-Agua', '11-Agua de 1000 litros', '2017-05-17', 6322),
(24, 'Constantino Jeremias ', '4-Propinas', '7-Propina Mensal', '2017-05-10', 2000),
(25, 'Jose', '4-Propinas', '8-Propina Semestral', '2017-05-17', 6565),
(26, 'Armando ', '1-Tv', '15-Zap Mega', '2017-05-12', 1876),
(27, 'Amiel Jorge', '3-Energia', '5-Energia de 100', '2017-05-25', 500),
(28, 'Edson Gomes', '13-Base', '1-Tv', '2017-10-27', 780),
(29, 'Madness', '1-Tv', '13-Base', '2017-10-27', 500),
(30, 'Sara', '13-Base', '1-Tv', '2017-10-27', 7750),
(31, 'Jay', '14-Plus', '1-Tv', '2017-10-27', 450);

-- --------------------------------------------------------

--
-- Table structure for table `servicos`
--

CREATE TABLE `servicos` (
  `idServicos` int(11) NOT NULL,
  `NomeDoServico` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servicos`
--

INSERT INTO `servicos` (`idServicos`, `NomeDoServico`) VALUES
(1, 'Tv'),
(2, 'Internet'),
(3, 'Energia'),
(4, 'Propinas'),
(5, 'Agua'),
(6, 'Credito Vodacom'),
(7, 'Credito Mcel'),
(8, 'Credito Movitel'),
(9, 'Renda');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idUser`, `password`, `nome`, `email`, `username`) VALUES
(1, 'A665A45920422F9D417E4867EFDC4FB8A04A1F3FFF1FA07E998E86F7F7A27AE3', NULL, NULL, ''),
(2, '8C6976E5B5410415BDE908BD4DEE15DFB167A9C873FC4BB8A81F6F2AB448A918', 'gomes', 'gomes@gmail.com', ''),
(3, 'A665A45920422F9D417E4867EFDC4FB8A04A1F3FFF1FA07E998E86F7F7A27AE3', 'jeremias', 'jeremias@gmail.com', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`);

--
-- Indexes for table `contratos`
--
ALTER TABLE `contratos`
  ADD PRIMARY KEY (`idContratos`),
  ADD KEY `FK_qjy7xih5q0w898gaq5e2xj9ly` (`Cliente_idCliente`),
  ADD KEY `FK_fsc9rljthq01l5a0mipsewfx0` (`servicos_idServicos`);

--
-- Indexes for table `pacote`
--
ALTER TABLE `pacote`
  ADD PRIMARY KEY (`idPacote`),
  ADD KEY `FK_ayaw4q8huureecevg6flrl3ja` (`servicos_idServicos`);

--
-- Indexes for table `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`idPagamento`);

--
-- Indexes for table `servicos`
--
ALTER TABLE `servicos`
  ADD PRIMARY KEY (`idServicos`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `contratos`
--
ALTER TABLE `contratos`
  MODIFY `idContratos` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pacote`
--
ALTER TABLE `pacote`
  MODIFY `idPacote` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `idPagamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `servicos`
--
ALTER TABLE `servicos`
  MODIFY `idServicos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `contratos`
--
ALTER TABLE `contratos`
  ADD CONSTRAINT `FK_fsc9rljthq01l5a0mipsewfx0` FOREIGN KEY (`servicos_idServicos`) REFERENCES `servicos` (`idServicos`),
  ADD CONSTRAINT `FK_qjy7xih5q0w898gaq5e2xj9ly` FOREIGN KEY (`Cliente_idCliente`) REFERENCES `cliente` (`idCliente`);

--
-- Constraints for table `pacote`
--
ALTER TABLE `pacote`
  ADD CONSTRAINT `FK_ayaw4q8huureecevg6flrl3ja` FOREIGN KEY (`servicos_idServicos`) REFERENCES `servicos` (`idServicos`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
